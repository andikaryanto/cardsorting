-- phpMyAdmin SQL Dump
-- version 4.8.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 17, 2018 at 06:07 AM
-- Server version: 10.1.33-MariaDB
-- PHP Version: 7.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cardsorting`
--

-- --------------------------------------------------------

--
-- Table structure for table `closemethod`
--

DROP TABLE IF EXISTS `closemethod`;
CREATE TABLE `closemethod` (
  `Id` int(11) NOT NULL,
  `IdMakanan` int(11) NOT NULL,
  `IdKategori` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `closemethod`
--

INSERT INTO `closemethod` (`Id`, `IdMakanan`, `IdKategori`) VALUES
(1, 37, 1),
(2, 51, 1),
(3, 52, 1),
(4, 55, 1),
(5, 57, 1),
(6, 59, 1),
(7, 66, 1),
(8, 74, 1),
(9, 78, 1),
(10, 79, 1),
(16, 11, 2),
(17, 14, 2),
(18, 21, 2),
(19, 39, 2),
(20, 53, 2),
(21, 75, 2),
(22, 83, 2),
(23, 100, 2),
(24, 104, 2),
(25, 105, 2),
(26, 108, 2),
(27, 111, 2),
(28, 116, 2),
(29, 117, 2),
(30, 121, 2),
(31, 123, 2),
(32, 124, 2),
(33, 125, 2),
(34, 126, 2),
(35, 127, 2),
(36, 128, 2),
(37, 129, 2),
(38, 132, 2),
(39, 134, 2),
(40, 136, 2),
(41, 138, 2),
(42, 139, 2),
(43, 140, 2),
(44, 141, 2),
(45, 142, 2),
(46, 143, 2),
(47, 144, 2),
(48, 146, 2),
(49, 147, 2),
(50, 148, 2),
(51, 149, 2),
(52, 151, 2),
(53, 153, 2),
(54, 155, 2),
(55, 156, 2),
(56, 159, 2),
(57, 160, 2),
(58, 161, 2),
(59, 162, 2),
(60, 163, 2),
(61, 164, 2),
(62, 165, 2),
(63, 170, 2),
(79, 17, 3),
(80, 19, 3),
(81, 20, 3),
(82, 22, 3),
(83, 23, 3),
(84, 24, 3),
(85, 28, 3),
(86, 29, 3),
(87, 31, 3),
(88, 32, 3),
(89, 34, 3),
(90, 36, 3),
(91, 38, 3),
(92, 41, 3),
(93, 42, 3),
(94, 43, 3),
(95, 47, 3),
(96, 50, 3),
(97, 56, 3),
(98, 61, 3),
(99, 62, 3),
(100, 64, 3),
(101, 65, 3),
(102, 67, 3),
(103, 68, 3),
(104, 70, 3),
(105, 72, 3),
(106, 76, 3),
(107, 77, 3),
(108, 80, 3),
(109, 81, 3),
(110, 82, 3),
(111, 84, 3),
(112, 87, 3),
(113, 89, 3),
(114, 90, 3),
(115, 91, 3),
(116, 92, 3),
(117, 93, 3),
(118, 96, 3),
(119, 97, 3),
(120, 157, 3),
(121, 167, 3),
(142, 4, 4),
(143, 5, 4),
(144, 6, 4),
(145, 8, 4),
(146, 9, 4),
(147, 12, 4),
(148, 13, 4),
(149, 35, 4),
(150, 58, 4),
(151, 73, 4),
(152, 113, 4),
(153, 119, 4),
(154, 152, 4),
(155, 166, 4),
(156, 171, 4),
(157, 44, 5),
(158, 95, 5),
(159, 150, 5),
(160, 158, 5),
(164, 18, 6),
(165, 25, 6),
(166, 69, 6),
(167, 88, 6),
(168, 94, 6),
(169, 101, 6),
(170, 102, 6),
(171, 107, 6),
(172, 109, 6),
(173, 131, 6),
(179, 16, 7),
(180, 103, 7),
(181, 112, 7),
(182, 130, 7),
(183, 145, 7),
(184, 172, 7),
(186, 27, 8),
(187, 40, 8),
(188, 114, 8),
(189, 122, 8),
(190, 133, 8),
(191, 135, 8),
(192, 137, 8),
(193, 63, 8),
(194, 106, 9),
(195, 110, 9),
(196, 118, 9),
(197, 120, 9),
(198, 173, 9),
(202, 88, 10),
(203, 66, 10),
(204, 86, 10),
(205, 96, 10),
(206, 51, 10),
(207, 78, 10),
(208, 34, 10),
(209, 44, 10),
(210, 7, 7);

-- --------------------------------------------------------

--
-- Table structure for table `kategorimakanan`
--

DROP TABLE IF EXISTS `kategorimakanan`;
CREATE TABLE `kategorimakanan` (
  `Id` int(11) NOT NULL,
  `Nama` varchar(100) NOT NULL,
  `Alias` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kategorimakanan`
--

INSERT INTO `kategorimakanan` (`Id`, `Nama`, `Alias`) VALUES
(1, 'Oleh-oleh/khas', 'Oleholehkhas'),
(2, 'Daging', 'Daging'),
(3, 'Jajanan', 'Jajanan'),
(4, 'Sayuran', 'Sayuran'),
(5, 'Gorengan', 'Gorengan'),
(6, 'Barat', 'Barat'),
(7, 'China', 'China'),
(8, 'Jepang', 'Jepang'),
(9, 'Bakmi', 'Bakmi'),
(10, 'Kue/Roti', 'KueRoti');

-- --------------------------------------------------------

--
-- Table structure for table `makanan`
--

DROP TABLE IF EXISTS `makanan`;
CREATE TABLE `makanan` (
  `Id` int(11) NOT NULL,
  `Nama` varchar(100) NOT NULL,
  `UrlGambar` varchar(1000) NOT NULL,
  `isFavorit` smallint(6) NOT NULL DEFAULT '0',
  `JumlahFavorit` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `makanan`
--

INSERT INTO `makanan` (`Id`, `Nama`, `UrlGambar`, `isFavorit`, `JumlahFavorit`) VALUES
(1, 'Gado - gado', 'resources/imgData/gadoGado.jpg', 1, 0),
(2, 'Ca bayam', 'resources/imgData/CaBayam.jpg', 0, 0),
(3, 'Bunthil', 'resources/imgData/Bunthil.jpg', 0, 0),
(4, 'Rumput laut', 'resources/imgData/rumputLaut.jpg', 0, 0),
(5, 'Urap', 'resources/imgData/urap.jpg', 0, 0),
(6, 'Salad', 'resources/imgData/salad.jpeg', 0, 0),
(7, 'Cap cay', 'resources/imgData/Capcay.jpg', 0, 0),
(8, 'Pecel', 'resources/imgData/pecel.jpeg', 1, 0),
(9, 'Trancam', 'resources/imgData/trancam.jpg', 0, 0),
(10, 'Ca kangkung', 'resources/imgData/CaKangkung.jpg', 0, 0),
(11, 'Selat', 'resources/imgData/Selat.jpg', 0, 0),
(12, 'Ketoprak', 'resources/imgData/ketoprak.jpg', 0, 0),
(13, 'Gudangan', 'resources/imgData/gudangan.jpg', 0, 0),
(14, 'Nugget', 'resources/imgData/Nugget.jpg', 0, 0),
(15, 'Singkong', 'resources/imgData/singkong.jpg', 0, 0),
(16, 'Cakwe', 'resources/imgData/Cakwe.jpg', 0, 0),
(17, 'Jenang mutiara', 'resources/imgData/jenangMutiara.jpg', 0, 0),
(18, 'Cemplon', 'resources/imgData/Cemplon.jpg', 0, 0),
(19, 'Empek-empek', 'resources/imgData/empekEmpek.jpg', 1, 0),
(20, 'Agar-agar', 'resources/imgData/agaragar.jpg', 0, 0),
(21, 'Sosis sapi', 'resources/imgData/SosisSapi.jpg', 0, 0),
(22, 'Mendung', 'resources/imgData/mendung.jpg', 0, 0),
(23, 'Rujak', 'resources/imgData/rujak.jpg', 0, 0),
(24, 'Jenang sumsum', 'resources/imgData/jenangSumsum.jpg', 0, 0),
(25, 'Crepes', 'resources/imgData/Crepes.jpg', 0, 0),
(26, 'Bubur kacang ijo', 'resources/imgData/BuburKacangIjo.jpg', 0, 0),
(27, 'Tempura', 'resources/imgData/tempura.jpg', 0, 0),
(28, 'Carang gesing', 'resources/imgData/CarangGesing.jpg', 0, 0),
(29, 'Jenang merah', 'resources/imgData/jenangMerah.jpg', 0, 0),
(30, 'Thiwul', 'resources/imgData/thiwul.jpg', 0, 0),
(31, 'Gandos', 'resources/imgData/gandos.jpg', 0, 0),
(32, 'Putu', 'resources/imgData/putu.jpg', 0, 0),
(33, 'Srabi kocor', 'resources/imgData/srabiKocor.jpg', 0, 0),
(34, 'Sagon', 'resources/imgData/sagon.jpg', 0, 0),
(35, 'Kentang rebus', 'resources/imgData/kentangRebus.jpg', 0, 0),
(36, 'Cireng', 'resources/imgData/Cireng.jpg', 0, 0),
(37, 'Alen-alen', 'resources/imgData/alenalen.jpg', 0, 0),
(38, 'Siomay', 'resources/imgData/siomay.jpg', 0, 0),
(39, 'Karage', 'resources/imgData/Karage.Jpg', 0, 0),
(40, 'Takoyaki', 'resources/imgData/takoyaki.jpg', 0, 0),
(41, 'Jadah', 'resources/imgData/jadah.jpg', 0, 0),
(42, 'Risoles', 'resources/imgData/risoles.jpg', 0, 0),
(43, 'Mata kebo', 'resources/imgData/mataKebo.jpg', 0, 0),
(44, 'Molen', 'resources/imgData/molen.jpg', 0, 0),
(45, 'Martabak manis', 'resources/imgData/martabakManis.jpg', 0, 0),
(46, 'Donats', 'resources/imgData/donat.jpg', 0, 0),
(47, 'Klepon', 'resources/imgData/klepon.jpg', 0, 0),
(48, 'Bolang baling', 'resources/imgData/BolangBaling', 0, 0),
(49, 'Zupa soup', 'resources/imgData/zuppaSoup.jpg', 0, 0),
(50, 'Ongol-ongol', 'resources/imgData/ongolOngol.jpg', 0, 0),
(51, 'Wajik', 'resources/imgData/ajik.jpg', 0, 0),
(52, 'Yangko', 'resources/imgData/yangko.jpg', 0, 0),
(53, 'Wader', 'resources/imgData/Wader.jpg\r\n', 0, 0),
(54, 'Ceriping singkong', 'resources/imgData/CeripingSingkong.jpg', 0, 0),
(55, 'Abon', 'resources/imgData/Abon.jpg', 0, 0),
(56, 'Tahu bacem', 'resources/imgData/tahuBacem.jpg', 0, 0),
(57, 'Enting-enting', 'resources/imgData/entingEnting.jpeg', 0, 0),
(58, 'Perkedel', 'resources/imgData/perkedel.jpg', 0, 0),
(59, 'Ndog gludug', 'resources/imgData/ndogGluduk.jpg', 0, 0),
(60, 'Rengginang', 'resources/imgData/rengginang.jpg', 0, 0),
(61, 'Growol', 'resources/imgData/growol.jpg', 0, 0),
(62, 'Bakpao', 'resources/imgData/Bakpao.jpg', 0, 0),
(63, 'Bakpia', 'resources/imgData/Bakpia.jpg', 0, 0),
(64, 'Getuk goreng', 'resources/imgData/gethukGoreng.jpg', 0, 0),
(65, 'Tahu bulat', 'resources/imgData/tahuBulat.jpg', 0, 0),
(66, 'Bika ambon', 'resources/imgData/BikaAmbon.jpg', 0, 0),
(67, 'Onde-onde', 'resources/imgData/ondeOnde.jpeg', 0, 0),
(68, 'Geplak', 'resources/imgData/geplak.jpg', 0, 0),
(69, 'Sandwich', 'resources/imgData/sandwich.jpg', 0, 0),
(70, 'Misoa', 'resources/imgData/misoa.jpg', 0, 0),
(71, 'Gathot', 'resources/imgData/gathot.jpg', 0, 0),
(72, 'Ampyang', 'resources/imgData/Ampyang.jpg', 0, 0),
(73, 'Jamur crispy', 'resources/imgData/jamurKrispi.jpg', 0, 0),
(74, 'Trasikan', 'resources/imgData/trasikan.jpg', 0, 0),
(75, 'Walang goreng', 'resources/imgData/WalangGoreng.jpg', 0, 0),
(76, 'Kacang goreng', 'resources/imgData/kacangGorengt.jpg', 0, 0),
(77, 'Peyek', 'resources/imgData/peyek.jpg', 0, 0),
(78, 'Wingko', 'resources/imgData/wingko.jpg', 0, 0),
(79, 'Legendar', 'resources/imgData/legendar.jpg', 0, 0),
(80, 'Timus', 'resources/imgData/timus.jpg', 0, 0),
(81, 'Cimol', 'resources/imgData/Cimol.jpg', 0, 0),
(82, 'Cenil', 'resources/imgData/Cenil.jpg', 0, 0),
(83, 'Otak-otak', 'resources/imgData/OtakOtak.jpg', 0, 0),
(84, 'Lempeng', 'resources/imgData/lempeng.jpg', 0, 0),
(85, 'Kripik tempe', 'resources/imgData/kripikTempe.jpg', 0, 0),
(86, 'Brownies', 'resources/imgData/Brownies.jpg', 0, 0),
(87, 'Gaplek', 'resources/imgData/gaplek.jpg', 0, 0),
(88, 'Roti bakar', 'resources/imgData/rotiBakar.jpg', 0, 0),
(89, 'Kipo', 'resources/imgData/kipo.jpg', 0, 0),
(90, 'Serabi', 'resources/imgData/serabi.jpg', 0, 0),
(91, 'Semar mesem', 'resources/imgData/semarMesem.jpg', 0, 0),
(92, 'Mendut', 'resources/imgData/mendut.jpg', 0, 0),
(93, 'Peyek kacang', 'resources/imgData/peyek.jpg', 0, 0),
(94, 'Makaroni', 'resources/imgData/makaroni.jpg', 0, 0),
(95, 'Kentang goreng', 'resources/imgData/kentangGoreng.jpg', 0, 0),
(96, 'Lumpia', 'resources/imgData/lumpia.jpeg', 0, 0),
(97, 'Legomoro', 'resources/imgData/legomoro.jpg', 0, 0),
(98, 'Kari', 'resources/imgData/kari.jpg', 0, 0),
(99, 'Fuyung hai', 'resources/imgData/fuyungHai.jpg', 0, 0),
(100, 'Cabuk', 'resources/imgData/Cabuk.jpg', 0, 0),
(101, 'Pasta', 'resources/imgData/pasta.jpg', 0, 0),
(102, 'Pizza', 'resources/imgData/pizza.jpg', 0, 0),
(103, 'Bakso', 'resources/imgData/Bakso.jpg', 0, 0),
(104, 'Iga sapi', 'resources/imgData/IgaSapi.jpg', 0, 0),
(105, 'Bistik', 'resources/imgData/Bistik.Jpg', 0, 0),
(106, 'Bakmi rebus', 'resources/imgData/BakmiRebus.jpg', 0, 0),
(107, 'Kebab', 'resources/imgData/kebab.jpg', 0, 0),
(108, 'Ikan', 'resources/imgData/Ikan.jpg', 0, 0),
(109, 'Lasagna', 'resources/imgData/lasagna.jpg', 0, 0),
(110, 'Indomie olahan', 'resources/imgData/indomieOlahan.jpg', 0, 0),
(111, 'Tumpeng', 'resources/imgData/Tumpeng.jpg', 0, 0),
(112, 'Swieke', 'resources/imgData/sweke.jpg', 0, 0),
(113, 'Sego abang', 'resources/imgData/segoAbang.jpg', 0, 0),
(114, 'Mie ramen', 'resources/imgData/mieRamen.jpg', 0, 0),
(115, 'Spaghetti', 'resources/imgData/spageti.jpg', 0, 0),
(116, 'Babi kecap', 'resources/imgData/babikecap.jpg', 0, 0),
(117, 'Opor ayam', 'resources/imgData/OporAyam.jpg', 0, 0),
(118, 'Bakmi goreng', 'resources/imgData/BakmiGoreng.jpg', 0, 0),
(119, 'Seblak', 'resources/imgData/seblak.jpg', 0, 0),
(120, 'Bihun', 'resources/imgData/Bihun.jpg', 0, 0),
(121, 'Rendang', 'resources/imgData/Rendang.jpg', 0, 0),
(122, 'Teriyaki', 'resources/imgData/teriyaki.jpg', 0, 0),
(123, 'Steak', 'resources/imgData/Steak.jpg', 0, 0),
(124, 'Bubur ayam', 'resources/imgData/BuburAyam.jpg', 0, 0),
(125, 'Bandeng', 'resources/imgData/Bandeng.jpg', 0, 0),
(126, 'Bakmoy', 'resources/imgData/Bakmoy.jpg', 0, 0),
(127, 'Sosis babi', 'resources/imgData/SosisBabi.jpg', 0, 0),
(128, 'Tongseng', 'resources/imgData/Tongseng.jpg', 0, 0),
(129, 'Ayam bakar', 'resources/imgData/AyamBakar.jpg', 0, 1),
(130, 'Ifumie', 'resources/imgData/ifumie.jpg', 0, 0),
(131, 'Burger', 'resources/imgData/Burger.jpg', 0, 0),
(132, 'Sop ayam', 'resources/imgData/SopAyam.Jpg', 0, 0),
(133, 'Sushi', 'resources/imgData/sushi.jpg', 0, 0),
(134, 'Soto', 'resources/imgData/Soto.Jpg', 0, 0),
(135, 'Yakiniku', 'resources/imgData/yakiniku.jpg', 0, 0),
(136, 'Brongkos', 'resources/imgData/Brongkos.jpg', 0, 0),
(137, 'Katsu', 'resources/imgData/Katsu.jpg', 0, 0),
(138, 'Sapi goreng', 'resources/imgData/SapiGoreng.jpg', 0, 0),
(139, 'Bebek bakar', 'resources/imgData/BebekBakar.jpg', 0, 0),
(140, 'Tengkleng', 'resources/imgData/Tengkleng.jpg', 0, 0),
(141, 'Ayam goreng', 'resources/imgData/AyamGoreng.jpg\r\n', 0, 0),
(142, 'Sate', 'resources/imgData/Sate.jpg\r\n', 0, 0),
(143, 'Rambak', 'resources/imgData/Rambak.jpg', 0, 0),
(144, 'Belut goreng', 'resources/imgData/BelutGoreng.jpg', 0, 0),
(145, 'Pangsit', 'resources/imgData/pangsit.jpg', 0, 0),
(146, 'Teri', 'resources/imgData/Teri.Jpg', 0, 0),
(147, 'Sate babi', 'resources/imgData/SateBabi.Jpg', 0, 0),
(148, 'Salmon', 'resources/imgData/Salmon.jpg', 0, 0),
(149, 'Kepiting saos tiram', 'resources/imgData/KepitingSausTiram.jpg', 0, 0),
(150, 'Telur dadar', 'resources/imgData/telurDadar.jpg', 0, 0),
(151, 'Lele goreng', 'resources/imgData/LeleGoreng.jpg', 0, 0),
(152, 'Sate jamur', 'resources/imgData/sateJamur.jpg', 0, 0),
(153, 'Pepes', 'resources/imgData/Pepes.Jpg\r\n', 0, 0),
(154, 'Sambal', 'resources/imgData/sambal.jpg', 0, 0),
(155, 'Bebek goreng', 'resources/imgData/BebekGoreng.Jpg', 0, 0),
(156, 'Iso babat', 'resources/imgData/IsoBabat.jpg', 0, 0),
(157, 'Batagor', 'resources/imgData/batagor.jpg', 0, 0),
(158, 'Bakwan', 'resources/imgData/Bakwan.jpg', 0, 0),
(159, 'Kikil', 'resources/imgData/Kikil.jpg', 0, 0),
(160, 'Bawal', 'resources/imgData/Bawal.jpg', 0, 0),
(161, 'Rica-rica', 'resources/imgData/ricarica.jpg', 0, 0),
(162, 'Paru-paru', 'resources/imgData/paruparu.jpg', 0, 0),
(163, 'Gulai', 'resources/imgData/Gulai.jpg', 0, 0),
(164, 'Udang goreng', 'resources/imgData/udanggoreng.jpg', 0, 0),
(165, 'Kepiting rebus', 'resources/imgData/kepitingrebus.jpg\r\n', 0, 0),
(166, 'Gudeg', 'resources/imgData/gudeg.jpg', 0, 0),
(167, 'Martabak asin', 'resources/imgData/martabakAsin.jpg', 0, 0),
(168, 'Cumi-cumi asam manis', 'resources/imgData/cumiAsamManis.jpg', 0, 0),
(169, 'Cotto makassar', 'resources/imgData/cotoMakassar.jpg', 0, 0),
(170, 'Dendeng', 'resources/imgData/Dendeng.jpg', 0, 0),
(171, 'Terong balado', 'resources/imgData/telurBalado.jpg', 0, 0),
(172, 'Chasiew', 'resources/imgData/Chasiew.jpg', 0, 0),
(173, 'Bakmi jawa', 'resources/imgData/BakmiJawa.jpg', 0, 0),
(174, 'kwetiau', 'resources/imgData/kwetiau.jpg', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `responden`
--

DROP TABLE IF EXISTS `responden`;
CREATE TABLE `responden` (
  `Id` int(11) NOT NULL,
  `Nama` varchar(100) NOT NULL,
  `Alamat` varchar(300) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `responden`
--

INSERT INTO `responden` (`Id`, `Nama`, `Alamat`) VALUES
(1, 'Alvi', NULL),
(2, 'Andrew', NULL),
(3, 'Chris', NULL),
(4, 'Nixon', NULL),
(5, 'Davin', NULL),
(6, 'Deana', NULL),
(7, 'Lala', NULL),
(8, 'Kefas', NULL),
(9, 'Alfian', NULL),
(10, 'Noel', NULL),
(11, 'Gangga', NULL),
(12, 'Hubert', NULL),
(13, 'Helviki', NULL),
(14, 'Rista', NULL),
(15, 'Andre', NULL),
(16, 'Meli', NULL),
(17, 'Tyok', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `Id` int(11) NOT NULL,
  `NamaUser` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`Id`, `NamaUser`, `Password`) VALUES
(1, 'admin', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `closemethod`
--
ALTER TABLE `closemethod`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `kategorimakanan`
--
ALTER TABLE `kategorimakanan`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `makanan`
--
ALTER TABLE `makanan`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `responden`
--
ALTER TABLE `responden`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `closemethod`
--
ALTER TABLE `closemethod`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=211;

--
-- AUTO_INCREMENT for table `kategorimakanan`
--
ALTER TABLE `kategorimakanan`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `makanan`
--
ALTER TABLE `makanan`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=175;

--
-- AUTO_INCREMENT for table `responden`
--
ALTER TABLE `responden`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
